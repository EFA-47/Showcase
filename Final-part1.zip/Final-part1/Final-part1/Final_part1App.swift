//
//  Final_part1App.swift
//  Final-part1
//
//  Created by Emir Fatih AYYILDIZ on 22.01.2024.
//

import SwiftUI

@main
struct Final_part1App: App {
    var body: some Scene {
        WindowGroup {
            UnlockScreen()
        }
    }
}
