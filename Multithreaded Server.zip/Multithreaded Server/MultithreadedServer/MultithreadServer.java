
public class MultithreadServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Server server = new Server(Server.DEFAULT_SERVER_PORT);
    }
    
}
