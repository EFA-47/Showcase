//
//  midterm_eayyildiz19App.swift
//  midterm_eayyildiz19
//
//  Created by Emir Fatih AYYILDIZ on 3.12.2023.
//

import SwiftUI

@main
struct CardGameApp: App {

    var body: some Scene {
        WindowGroup {
            FruitListView()
        }
    }
}
