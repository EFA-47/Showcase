//
//  FruitDataSourceDelegate.swift
//  midterm_eayyildiz19
//
//  Created by Emir Fatih AYYILDIZ on 3.12.2023.
//

import Foundation

protocol FruitDataSourceDelegate {
    func fruitListLoaded(fruitList: [Fruit])
}
