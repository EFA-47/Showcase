 monitor deliveryMonitor {
 struct order {
 int id;
 int dist;
 int size;
 };

 int available_cars; //number of available delivery guys
 struct order waiting_orders[M];
 int num_waiting; //number of orders currently waiting
 // !you can introduce shared variables

 // !implement this function
 void request_delivery(int order_id, int distance, int size)
 {
 waiting_orders[num_waiting].id = order_id;
 waiting_orders[num_waiting].dist = distance;
 waiting_orders[num_waiting].size = size;
 }

 void release_car() {
 // !implement this function
 }

 void initialize()
 {
 available_cars = 5;
 num_waiting = 0;
 }
 }
