//
//  comp319A2App.swift
//  comp319A2
//
//  Created by Emir Fatih AYYILDIZ on 17.11.2023.
//

import SwiftUI

@main
struct Comp319A2App: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
