//
//  ContentView.swift
//  comp319A2
//
//  Created by Emir Fatih AYYILDIZ on 17.11.2023.
//

import SwiftUI
struct ContentView: App {

    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
