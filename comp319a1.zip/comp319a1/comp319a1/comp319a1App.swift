//
//  comp319a1App.swift
//  comp319a1
//
//  Created by Emir Fatih AYYILDIZ on 14.10.2023.
//

import SwiftUI

@main
struct comp319a1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
