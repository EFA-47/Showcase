package main.ymir;

import main.Game;

public interface YmirStrategy {

    public void activateAbility(Ymir ymir, Game parent);
}
